"""
ARINC 429 Digital Twin — Transmitter GUI
Professional avionics-style dark UI built with tkinter.
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import queue
import time
from datetime import datetime


# ── Colour palette (avionics dark theme) ─────────────────────────────────────
BG        = "#0d1117"
BG2       = "#161b22"
BG3       = "#21262d"
FG        = "#e6edf3"
FG_DIM    = "#8b949e"
GREEN     = "#3fb950"
YELLOW    = "#d29922"
RED       = "#f85149"
BLUE      = "#58a6ff"
ORANGE    = "#f0883e"
MONO      = ("Consolas", 10)
MONO_SM   = ("Consolas", 9)
TITLE_F   = ("Consolas", 11, "bold")


# ── SSM colour helper ─────────────────────────────────────────────────────────
def ssm_color(ssm_bits: str) -> str:
    return {
        "11": GREEN,
        "00": RED,
        "01": YELLOW,
        "10": ORANGE,
    }.get(ssm_bits, FG_DIM)


def ssm_label(ssm_bits: str) -> str:
    return {
        "11": "NRM",
        "00": "FAIL",
        "01": "NCD",
        "10": "TEST",
    }.get(ssm_bits, "???")


# ── Transmitter Application ───────────────────────────────────────────────────
class TransmitterApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ARINC 429 Digital Twin — Transmitter")
        self.configure(bg=BG)
        self.geometry("1000x780")
        self.resizable(True, True)

        self._sim_thread  = None
        self._running     = False
        self._ui_queue    = queue.Queue()   # thread → UI updates
        self._eth_tx      = None

        self._build_ui()
        self._poll_ui_queue()

    # ── UI Construction ───────────────────────────────────────────────────

    def _build_ui(self):
        self._build_config_frame()
        self._build_status_frame()
        self._build_monitor_frame()
        self._build_fault_frame()
        self._build_log_frame()

    def _build_config_frame(self):
        f = tk.LabelFrame(self, text=" CONFIGURATION ", bg=BG, fg=BLUE,
                          font=TITLE_F, bd=1, relief="solid")
        f.pack(fill="x", padx=8, pady=(8, 4))

        # Left — scenario
        left = tk.Frame(f, bg=BG)
        left.pack(side="left", fill="x", expand=True, padx=8, pady=6)

        tk.Label(left, text="Scenario File", bg=BG, fg=FG_DIM,
                 font=MONO_SM).grid(row=0, column=0, sticky="w")
        self._scenario_var = tk.StringVar(value="config/scenarios/ils_approch.yaml")
        tk.Entry(left, textvariable=self._scenario_var, bg=BG3, fg=FG,
                 font=MONO, width=38, insertbackground=FG,
                 relief="flat").grid(row=0, column=1, padx=4)
        tk.Button(left, text="Browse", bg=BG3, fg=BLUE, font=MONO_SM,
                  relief="flat", cursor="hand2",
                  command=self._browse_scenario).grid(row=0, column=2, padx=4)

        tk.Label(left, text="Duration (s)", bg=BG, fg=FG_DIM,
                 font=MONO_SM).grid(row=1, column=0, sticky="w", pady=4)
        self._duration_var = tk.StringVar(value="")
        tk.Entry(left, textvariable=self._duration_var, bg=BG3, fg=FG,
                 font=MONO, width=10, insertbackground=FG,
                 relief="flat").grid(row=1, column=1, sticky="w", padx=4)
        tk.Label(left, text="(blank = use YAML value)", bg=BG, fg=FG_DIM,
                 font=MONO_SM).grid(row=1, column=2, sticky="w")

        # Right — network
        right = tk.Frame(f, bg=BG)
        right.pack(side="right", padx=8, pady=6)

        tk.Label(right, text="Receiver IP", bg=BG, fg=FG_DIM,
                 font=MONO_SM).grid(row=0, column=0, sticky="w")
        self._host_var = tk.StringVar(value="127.0.0.1")
        tk.Entry(right, textvariable=self._host_var, bg=BG3, fg=FG,
                 font=MONO, width=18, insertbackground=FG,
                 relief="flat").grid(row=0, column=1, padx=4)

        tk.Label(right, text="Port", bg=BG, fg=FG_DIM,
                 font=MONO_SM).grid(row=1, column=0, sticky="w", pady=4)
        self._port_var = tk.StringVar(value="5429")
        tk.Entry(right, textvariable=self._port_var, bg=BG3, fg=FG,
                 font=MONO, width=8, insertbackground=FG,
                 relief="flat").grid(row=1, column=1, sticky="w", padx=4)

        btn_f = tk.Frame(right, bg=BG)
        btn_f.grid(row=2, column=0, columnspan=2, pady=6)
        self._run_btn = tk.Button(btn_f, text="▶  Connect & Run", bg=GREEN,
                                  fg=BG, font=("Consolas", 10, "bold"),
                                  relief="flat", cursor="hand2", padx=10,
                                  command=self._start_simulation)
        self._run_btn.pack(side="left", padx=4)
        self._stop_btn = tk.Button(btn_f, text="■  Stop", bg=RED, fg=BG,
                                   font=("Consolas", 10, "bold"), relief="flat",
                                   cursor="hand2", padx=10, state="disabled",
                                   command=self._stop_simulation)
        self._stop_btn.pack(side="left", padx=4)

    def _build_status_frame(self):
        f = tk.Frame(self, bg=BG2, bd=1, relief="solid")
        f.pack(fill="x", padx=8, pady=2)

        self._status_dot = tk.Label(f, text="●", fg=FG_DIM, bg=BG2,
                                    font=("Consolas", 12))
        self._status_dot.pack(side="left", padx=(8, 2))
        self._status_lbl = tk.Label(f, text="IDLE", fg=FG_DIM, bg=BG2,
                                    font=("Consolas", 10, "bold"))
        self._status_lbl.pack(side="left", padx=(0, 16))

        tk.Label(f, text="Sim Time:", bg=BG2, fg=FG_DIM,
                 font=MONO_SM).pack(side="left")
        self._simtime_lbl = tk.Label(f, text="0.0s / —", fg=FG, bg=BG2,
                                     font=MONO)
        self._simtime_lbl.pack(side="left", padx=(4, 12))

        self._progress = ttk.Progressbar(f, length=180, mode="determinate")
        self._progress.pack(side="left", padx=8)

        tk.Label(f, text="Words TX:", bg=BG2, fg=FG_DIM,
                 font=MONO_SM).pack(side="left", padx=(12, 0))
        self._words_lbl = tk.Label(f, text="0", fg=GREEN, bg=BG2, font=MONO)
        self._words_lbl.pack(side="left", padx=(4, 12))

        tk.Label(f, text="Parity Errors:", bg=BG2, fg=FG_DIM,
                 font=MONO_SM).pack(side="left")
        self._parity_lbl = tk.Label(f, text="0", fg=FG, bg=BG2, font=MONO)
        self._parity_lbl.pack(side="left", padx=4)

    def _build_monitor_frame(self):
        f = tk.LabelFrame(self, text=" LIVE BUS MONITOR ", bg=BG, fg=BLUE,
                          font=TITLE_F, bd=1, relief="solid")
        f.pack(fill="both", expand=True, padx=8, pady=4)

        cols = ("channel", "lru", "label", "name", "value", "units",
                "ssm", "rate")
        self._tree = ttk.Treeview(f, columns=cols, show="headings",
                                  height=8)
        widths = [100, 90, 70, 200, 100, 60, 70, 70]
        headers = ["Channel", "LRU", "Label", "Parameter Name",
                   "Value", "Units", "SSM", "Rate Hz"]
        for col, w, h in zip(cols, widths, headers):
            self._tree.heading(col, text=h)
            self._tree.column(col, width=w, anchor="center")

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", background=BG2, foreground=FG,
                        fieldbackground=BG2, font=MONO_SM, rowheight=22)
        style.configure("Treeview.Heading", background=BG3, foreground=BLUE,
                        font=("Consolas", 9, "bold"))
        style.map("Treeview", background=[("selected", BG3)])

        sb = ttk.Scrollbar(f, orient="vertical", command=self._tree.yview)
        self._tree.configure(yscrollcommand=sb.set)
        self._tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        self._monitor_rows = {}   # key → iid

    def _build_fault_frame(self):
        f = tk.LabelFrame(self, text=" FAULT INJECTION ", bg=BG, fg=ORANGE,
                          font=TITLE_F, bd=1, relief="solid")
        f.pack(fill="x", padx=8, pady=4)

        inner = tk.Frame(f, bg=BG)
        inner.pack(padx=8, pady=6, fill="x")

        tk.Label(inner, text="LRU", bg=BG, fg=FG_DIM,
                 font=MONO_SM).grid(row=0, column=0, padx=4)
        self._fault_lru = ttk.Combobox(inner, width=10, font=MONO_SM,
            values=["ADIRU_1", "ILS_1", "RA_1", "FMC_1", "XPDR_1"])
        self._fault_lru.set("ADIRU_1")
        self._fault_lru.grid(row=0, column=1, padx=4)

        tk.Label(inner, text="Label", bg=BG, fg=FG_DIM,
                 font=MONO_SM).grid(row=0, column=2, padx=4)
        self._fault_label = ttk.Combobox(inner, width=8, font=MONO_SM,
            values=["0o203", "0o173", "0o175", "0o164", "0o101", "0o204"])
        self._fault_label.set("0o203")
        self._fault_label.grid(row=0, column=3, padx=4)

        tk.Label(inner, text="Type", bg=BG, fg=FG_DIM,
                 font=MONO_SM).grid(row=0, column=4, padx=4)
        self._fault_type = ttk.Combobox(inner, width=20, font=MONO_SM,
            values=["PARITY_ERROR", "SSM_FAILURE_WARNING", "SSM_NCD",
                    "BIT_FLIP", "LABEL_DROP", "BUS_FREEZE"])
        self._fault_type.set("PARITY_ERROR")
        self._fault_type.grid(row=0, column=5, padx=4)

        tk.Label(inner, text="Duration(s)", bg=BG, fg=FG_DIM,
                 font=MONO_SM).grid(row=0, column=6, padx=4)
        self._fault_dur = tk.Entry(inner, width=5, bg=BG3, fg=FG,
                                   font=MONO_SM, insertbackground=FG,
                                   relief="flat")
        self._fault_dur.insert(0, "5")
        self._fault_dur.grid(row=0, column=7, padx=4)

        tk.Label(inner, text="Prob", bg=BG, fg=FG_DIM,
                 font=MONO_SM).grid(row=0, column=8, padx=4)
        self._fault_prob = tk.Entry(inner, width=5, bg=BG3, fg=FG,
                                    font=MONO_SM, insertbackground=FG,
                                    relief="flat")
        self._fault_prob.insert(0, "1.0")
        self._fault_prob.grid(row=0, column=9, padx=4)

        tk.Button(inner, text="⚡ Fire Now", bg=ORANGE, fg=BG,
                  font=("Consolas", 10, "bold"), relief="flat",
                  cursor="hand2", padx=8,
                  command=self._inject_fault).grid(row=0, column=10, padx=8)

    def _build_log_frame(self):
        f = tk.LabelFrame(self, text=" EVENT LOG ", bg=BG, fg=BLUE,
                          font=TITLE_F, bd=1, relief="solid")
        f.pack(fill="x", padx=8, pady=(4, 8))

        self._log = tk.Text(f, height=6, bg=BG2, fg=FG_DIM, font=MONO_SM,
                            state="disabled", relief="flat",
                            insertbackground=FG)
        sb = ttk.Scrollbar(f, orient="vertical", command=self._log.yview)
        self._log.configure(yscrollcommand=sb.set)
        self._log.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        self._log.tag_config("green",  foreground=GREEN)
        self._log.tag_config("red",    foreground=RED)
        self._log.tag_config("yellow", foreground=YELLOW)
        self._log.tag_config("blue",   foreground=BLUE)

    # ── Simulation control ────────────────────────────────────────────────

    def _browse_scenario(self):
        path = filedialog.askopenfilename(
            filetypes=[("YAML files", "*.yaml *.yml"), ("All files", "*.*")])
        if path:
            self._scenario_var.set(path)

    def _start_simulation(self):
        if self._running:
            return
        scenario = self._scenario_var.get().strip()
        if not scenario:
            messagebox.showerror("Error", "Please select a scenario file.")
            return

        host = self._host_var.get().strip()
        port = int(self._port_var.get().strip() or "5429")
        dur_str = self._duration_var.get().strip()
        duration = float(dur_str) if dur_str else None

        self._running = True
        self._run_btn.config(state="disabled")
        self._stop_btn.config(state="normal")
        self._set_status("CONNECTING", YELLOW)

        self._sim_thread = threading.Thread(
            target=self._run_simulation,
            args=(scenario, host, port, duration),
            daemon=True
        )
        self._sim_thread.start()

    def _stop_simulation(self):
        self._running = False
        self._log_event("Simulation stop requested by user", "yellow")

    def _run_simulation(self, scenario: str, host: str, port: int,
                        duration):
        """Runs in background thread."""
        try:
            from src.engine.simulation import Simulation
            from src.network.transmitter import EthernetTransmitter

            # Connect ethernet
            self._eth_tx = EthernetTransmitter(host=host, port=port)
            self._eth_tx.connect()
            self._ui_queue.put(("log", f"Connected to {host}:{port}", "green"))
            self._ui_queue.put(("status", "RUNNING", GREEN))

            sim = Simulation()
            sim.load_scenario(scenario)

            total_s = duration or sim.scenario.config.duration_s

            # Word counter listener
            self._word_count = 0
            def count_words(word):
                self._word_count += 1

            sim.add_listener(self._eth_tx.send)
            sim.add_listener(count_words)
            sim.add_listener(self._make_monitor_listener())

            self._ui_queue.put(("log",
                f"Simulation started — {sim.scenario.config.name}", "blue"))

            # Run in small chunks so we can update UI and check stop flag
            from src.engine.simulation import Simulation as _S
            import time as _t

            chunk = 1.0   # 1 second chunks for UI responsiveness
            elapsed = 0.0
            t_start = _t.monotonic()

            while self._running and elapsed < total_s:
                step = min(chunk, total_s - elapsed)
                sim.run(duration_s=step)
                elapsed += step
                pct = (elapsed / total_s) * 100
                self._ui_queue.put(("progress", elapsed, total_s, pct,
                                    self._word_count,
                                    sim.monitor.parity_error_count))

            self._eth_tx.close()
            self._ui_queue.put(("log",
                f"Simulation complete — {self._word_count} words transmitted",
                "green"))
            self._ui_queue.put(("status", "COMPLETE", GREEN))

        except ConnectionRefusedError:
            self._ui_queue.put(("log",
                f"Connection refused — is receiver running on {host}:{port}?",
                "red"))
            self._ui_queue.put(("status", "ERROR", RED))
        except Exception as e:
            self._ui_queue.put(("log", f"Error: {e}", "red"))
            self._ui_queue.put(("status", "ERROR", RED))
        finally:
            self._running = False
            self._ui_queue.put(("buttons",))

    def _make_monitor_listener(self):
        """Returns a listener that pushes monitor updates to the UI queue."""
        def listener(word):
            key = (word.bus_id, word.lru_id, word.label_oct)
            ssm_str = f"{word.ssm:02b}"
            val_str = f"{word.decoded_value:.4f}" if word.decoded_value is not None else "—"
            from src.core.label_db import get_label
            ldef = get_label(word.label_oct)
            name  = ldef.name  if ldef else f"0o{word.label_oct:o}"
            units = ldef.units if ldef else ""
            self._ui_queue.put(("monitor", key, word.bus_id, word.lru_id,
                                 f"0o{word.label_oct:o}", name,
                                 val_str, units, ssm_str))
        return listener

    def _inject_fault(self):
        self._log_event(
            f"Manual fault: {self._fault_type.get()} on "
            f"{self._fault_lru.get()} {self._fault_label.get()} "
            f"dur={self._fault_dur.get()}s prob={self._fault_prob.get()}",
            "yellow"
        )
        # Runtime fault injection would hook into the running simulation's
        # fault injector here — wired in a full implementation

    # ── UI update helpers ─────────────────────────────────────────────────

    def _set_status(self, text: str, color: str):
        self._status_dot.config(fg=color)
        self._status_lbl.config(text=text, fg=color)

    def _log_event(self, msg: str, tag: str = ""):
        ts = datetime.now().strftime("%H:%M:%S.%f")[:12]
        self._log.config(state="normal")
        self._log.insert("end", f"[{ts}]  {msg}\n", tag)
        self._log.see("end")
        self._log.config(state="disabled")

    def _update_monitor_row(self, key, channel, lru, label, name,
                             value, units, ssm_bits):
        color = ssm_color(ssm_bits)
        ssm_text = ssm_label(ssm_bits)
        row = (channel, lru, label, name, value, units, ssm_text, "")
        if key in self._monitor_rows:
            iid = self._monitor_rows[key]
            self._tree.item(iid, values=row)
            self._tree.tag_configure(str(key), foreground=color)
        else:
            iid = self._tree.insert("", "end", values=row,
                                    tags=(str(key),))
            self._tree.tag_configure(str(key), foreground=color)
            self._monitor_rows[key] = iid

    def _poll_ui_queue(self):
        """Drain the UI queue and apply updates — runs on main thread."""
        try:
            while True:
                msg = self._ui_queue.get_nowait()
                kind = msg[0]
                if kind == "log":
                    self._log_event(msg[1], msg[2] if len(msg) > 2 else "")
                elif kind == "status":
                    self._set_status(msg[1], msg[2])
                elif kind == "progress":
                    _, elapsed, total, pct, words, errors = msg
                    self._simtime_lbl.config(
                        text=f"{elapsed:.1f}s / {total:.1f}s")
                    self._progress["value"] = pct
                    self._words_lbl.config(text=f"{words:,}")
                    self._parity_lbl.config(
                        text=str(errors),
                        fg=RED if errors > 0 else FG)
                elif kind == "monitor":
                    _, key, ch, lru, lbl, name, val, units, ssm = msg
                    self._update_monitor_row(
                        key, ch, lru, lbl, name, val, units, ssm)
                elif kind == "buttons":
                    self._run_btn.config(state="normal")
                    self._stop_btn.config(state="disabled")
        except queue.Empty:
            pass
        self.after(100, self._poll_ui_queue)


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = TransmitterApp()
    app.mainloop()
