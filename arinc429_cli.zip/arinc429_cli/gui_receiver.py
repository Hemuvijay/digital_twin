"""
ARINC 429 Digital Twin — Receiver GUI
Professional avionics-style dark UI built with tkinter.
"""

import tkinter as tk
from tkinter import ttk, filedialog
import threading
import queue
from datetime import datetime


# ── Colour palette (same as transmitter) ─────────────────────────────────────
BG        = "#0d1117"
BG2       = "#161b22"
BG3       = "#21262d"
FG        = "#e6edf3"
FG_DIM    = "#8b949e"
GREEN     = "#3fb950"
YELLOW    = "#d29922"
RED       = "#f85149"
BLUE      = "#58a6ff"
ORANGE    = "#f0883e"
MONO      = ("Consolas", 10)
MONO_SM   = ("Consolas", 9)
TITLE_F   = ("Consolas", 11, "bold")


def ssm_color(ssm_bits: str) -> str:
    return {"11": GREEN, "00": RED, "01": YELLOW, "10": ORANGE}.get(ssm_bits, FG_DIM)

def ssm_label(ssm_bits: str) -> str:
    return {"11": "NRM", "00": "FAIL", "01": "NCD", "10": "TEST"}.get(ssm_bits, "???")

def result_color(result: str) -> str:
    return {"PASS": GREEN, "FAIL": RED, "MISSED": ORANGE,
            "PENDING": YELLOW}.get(result, FG_DIM)


class ReceiverApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ARINC 429 Digital Twin — Receiver")
        self.configure(bg=BG)
        self.geometry("1000x780")
        self.resizable(True, True)

        self._rx_thread  = None
        self._running    = False
        self._ui_queue   = queue.Queue()
        self._vectors_path = None

        self._build_ui()
        self._poll_ui_queue()

    # ── UI Construction ───────────────────────────────────────────────────

    def _build_ui(self):
        self._build_connection_frame()
        self._build_monitor_frame()
        self._build_validation_frame()
        self._build_log_frame()

    def _build_connection_frame(self):
        f = tk.LabelFrame(self, text=" CONNECTION ", bg=BG, fg=BLUE,
                          font=TITLE_F, bd=1, relief="solid")
        f.pack(fill="x", padx=8, pady=(8, 4))

        inner = tk.Frame(f, bg=BG)
        inner.pack(padx=8, pady=6, fill="x")

        tk.Label(inner, text="Listen on Port", bg=BG, fg=FG_DIM,
                 font=MONO_SM).grid(row=0, column=0, padx=4)
        self._port_var = tk.StringVar(value="5429")
        tk.Entry(inner, textvariable=self._port_var, bg=BG3, fg=FG,
                 font=MONO, width=8, insertbackground=FG,
                 relief="flat").grid(row=0, column=1, padx=4)

        self._listen_btn = tk.Button(
            inner, text="▶  Start Listening", bg=GREEN, fg=BG,
            font=("Consolas", 10, "bold"), relief="flat", cursor="hand2",
            padx=10, command=self._start_listening)
        self._listen_btn.grid(row=0, column=2, padx=8)

        self._stop_btn = tk.Button(
            inner, text="■  Stop", bg=RED, fg=BG,
            font=("Consolas", 10, "bold"), relief="flat", cursor="hand2",
            padx=10, state="disabled", command=self._stop_listening)
        self._stop_btn.grid(row=0, column=3, padx=4)

        tk.Button(inner, text="📂 Load Vectors", bg=BG3, fg=BLUE,
                  font=MONO_SM, relief="flat", cursor="hand2",
                  command=self._load_vectors).grid(row=0, column=4, padx=8)

        self._vectors_lbl = tk.Label(inner, text="No vectors loaded",
                                     bg=BG, fg=FG_DIM, font=MONO_SM)
        self._vectors_lbl.grid(row=0, column=5, padx=4)

        tk.Button(inner, text="💾 Export CSV", bg=BG3, fg=BLUE,
                  font=MONO_SM, relief="flat", cursor="hand2",
                  command=self._export_csv).grid(row=0, column=6, padx=8)

        # Status row
        status_f = tk.Frame(f, bg=BG2)
        status_f.pack(fill="x", padx=0, pady=(0, 0))

        self._conn_dot = tk.Label(status_f, text="●", fg=FG_DIM, bg=BG2,
                                  font=("Consolas", 12))
        self._conn_dot.pack(side="left", padx=(8, 2))
        self._conn_lbl = tk.Label(status_f, text="IDLE", fg=FG_DIM, bg=BG2,
                                  font=("Consolas", 10, "bold"))
        self._conn_lbl.pack(side="left", padx=(0, 16))

        tk.Label(status_f, text="Words RX:", bg=BG2, fg=FG_DIM,
                 font=MONO_SM).pack(side="left")
        self._words_lbl = tk.Label(status_f, text="0", fg=GREEN, bg=BG2,
                                   font=MONO)
        self._words_lbl.pack(side="left", padx=(4, 12))

        tk.Label(status_f, text="Parity Errors:", bg=BG2, fg=FG_DIM,
                 font=MONO_SM).pack(side="left")
        self._parity_lbl = tk.Label(status_f, text="0", fg=FG, bg=BG2,
                                    font=MONO)
        self._parity_lbl.pack(side="left", padx=4)

    def _build_monitor_frame(self):
        f = tk.LabelFrame(self, text=" LIVE BUS MONITOR ", bg=BG, fg=BLUE,
                          font=TITLE_F, bd=1, relief="solid")
        f.pack(fill="both", expand=True, padx=8, pady=4)

        cols = ("channel", "tx_lru", "label", "name", "value", "units", "ssm")
        self._tree = ttk.Treeview(f, columns=cols, show="headings", height=8)
        widths  = [100, 90, 70, 200, 110, 60, 70]
        headers = ["Channel", "TX LRU", "Label", "Parameter Name",
                   "Value", "Units", "SSM"]
        for col, w, h in zip(cols, widths, headers):
            self._tree.heading(col, text=h)
            self._tree.column(col, width=w, anchor="center")

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", background=BG2, foreground=FG,
                        fieldbackground=BG2, font=MONO_SM, rowheight=22)
        style.configure("Treeview.Heading", background=BG3, foreground=BLUE,
                        font=("Consolas", 9, "bold"))
        style.map("Treeview", background=[("selected", BG3)])

        sb = ttk.Scrollbar(f, orient="vertical", command=self._tree.yview)
        self._tree.configure(yscrollcommand=sb.set)
        self._tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self._monitor_rows = {}

    def _build_validation_frame(self):
        f = tk.LabelFrame(self, text=" VALIDATION RESULTS ", bg=BG, fg=BLUE,
                          font=TITLE_F, bd=1, relief="solid")
        f.pack(fill="x", padx=8, pady=4)

        cols = ("id", "description", "result", "value", "reason")
        self._val_tree = ttk.Treeview(f, columns=cols, show="headings",
                                      height=5)
        widths  = [70, 280, 80, 120, 200]
        headers = ["ID", "Description", "Result", "Actual Value", "Reason"]
        for col, w, h in zip(cols, widths, headers):
            self._val_tree.heading(col, text=h)
            self._val_tree.column(col, width=w, anchor="w")

        sb2 = ttk.Scrollbar(f, orient="vertical",
                             command=self._val_tree.yview)
        self._val_tree.configure(yscrollcommand=sb2.set)
        self._val_tree.pack(side="left", fill="both", expand=True)
        sb2.pack(side="right", fill="y")
        self._val_rows = {}

    def _build_log_frame(self):
        f = tk.LabelFrame(self, text=" EVENT LOG ", bg=BG, fg=BLUE,
                          font=TITLE_F, bd=1, relief="solid")
        f.pack(fill="x", padx=8, pady=(4, 8))

        self._log = tk.Text(f, height=6, bg=BG2, fg=FG_DIM, font=MONO_SM,
                            state="disabled", relief="flat",
                            insertbackground=FG)
        sb = ttk.Scrollbar(f, orient="vertical", command=self._log.yview)
        self._log.configure(yscrollcommand=sb.set)
        self._log.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        self._log.tag_config("green",  foreground=GREEN)
        self._log.tag_config("red",    foreground=RED)
        self._log.tag_config("yellow", foreground=YELLOW)
        self._log.tag_config("blue",   foreground=BLUE)

    # ── Receiver control ──────────────────────────────────────────────────

    def _load_vectors(self):
        path = filedialog.askopenfilename(
            filetypes=[("YAML files", "*.yaml *.yml"), ("All files", "*.*")])
        if path:
            self._vectors_path = path
            import os
            self._vectors_lbl.config(
                text=os.path.basename(path), fg=GREEN)
            self._log_event(f"Test vectors loaded: {path}", "blue")

    def _export_csv(self):
        if not hasattr(self, "_logger") or self._logger.word_count() == 0:
            self._log_event("No data to export yet", "yellow")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if path:
            self._logger.to_csv(path)
            self._log_event(f"Exported {self._logger.word_count()} words to {path}", "green")

    def _start_listening(self):
        if self._running:
            return
        port = int(self._port_var.get().strip() or "5429")
        self._running = True
        self._listen_btn.config(state="disabled")
        self._stop_btn.config(state="normal")
        self._set_conn_status("LISTENING", YELLOW)

        self._rx_thread = threading.Thread(
            target=self._run_receiver, args=(port,), daemon=True)
        self._rx_thread.start()

    def _stop_listening(self):
        self._running = False
        self._log_event("Receiver stopped by user", "yellow")

    def _run_receiver(self, port: int):
        from src.network.receiver import EthernetReceiver
        from src.monitor.monitor import BusMonitor
        from src.monitor.logger import BusLogger
        from src.validation.engine import ValidationEngine

        self._monitor   = BusMonitor()
        self._logger    = BusLogger()
        self._validator = ValidationEngine()

        if self._vectors_path:
            self._validator.load_vectors_yaml(self._vectors_path)
            self._ui_queue.put(("log",
                f"Validation vectors loaded: {self._vectors_path}", "blue"))

        rx = EthernetReceiver(host="0.0.0.0", port=port)
        rx.add_listener(self._monitor.ingest)
        rx.add_listener(self._logger.write)
        rx.add_listener(self._validator.check)
        rx.add_listener(self._make_monitor_listener())
        rx.add_listener(self._make_validation_listener())

        self._ui_queue.put(("log", f"Listening on port {port} ...", "blue"))

        try:
            rx.run()
        except Exception as e:
            self._ui_queue.put(("log", f"Receiver error: {e}", "red"))
        finally:
            self._running = False
            self._ui_queue.put(("conn_status", "DISCONNECTED", FG_DIM))
            self._ui_queue.put(("buttons",))
            # Final validation report
            report = self._validator.summary()
            for v in report.get("vectors", []):
                self._ui_queue.put(("val_update", v["id"], v["description"],
                                    v["result"],
                                    str(v.get("actual_value") or "—"),
                                    v.get("reason", "")))
            self._ui_queue.put(("log",
                f"Session ended — {self._logger.word_count()} words received",
                "green"))

    def _make_monitor_listener(self):
        word_count = [0]
        parity_errors = [0]
        def listener(word):
            word_count[0] += 1
            if not word.parity_ok:
                parity_errors[0] += 1
            key = (word.bus_id, word.lru_id, word.label_oct)
            ssm_str = f"{word.ssm:02b}"
            val_str = (f"{word.decoded_value:.4f}"
                       if word.decoded_value is not None else "—")
            from src.core.label_db import get_label
            ldef  = get_label(word.label_oct)
            name  = ldef.name  if ldef else f"0o{word.label_oct:o}"
            units = ldef.units if ldef else ""
            self._ui_queue.put(("monitor", key, word.bus_id, word.lru_id,
                                 f"0o{word.label_oct:o}", name,
                                 val_str, units, ssm_str,
                                 word_count[0], parity_errors[0]))
        return listener

    def _make_validation_listener(self):
        from src.validation.engine import VectorResult
        def listener(word):
            if not hasattr(self, "_validator"):
                return
            for tv in self._validator._vectors:
                if tv.result != VectorResult.PENDING:
                    self._ui_queue.put((
                        "val_update", tv.vector_id, tv.description,
                        tv.result.value,
                        str(round(tv.actual_value, 4))
                        if tv.actual_value is not None else "—",
                        tv.failure_reason
                    ))
        return listener

    # ── UI helpers ────────────────────────────────────────────────────────

    def _set_conn_status(self, text: str, color: str):
        self._conn_dot.config(fg=color)
        self._conn_lbl.config(text=text, fg=color)

    def _log_event(self, msg: str, tag: str = ""):
        ts = datetime.now().strftime("%H:%M:%S.%f")[:12]
        self._log.config(state="normal")
        self._log.insert("end", f"[{ts}]  {msg}\n", tag)
        self._log.see("end")
        self._log.config(state="disabled")

    def _update_monitor_row(self, key, channel, lru, label, name,
                             value, units, ssm_bits):
        color = ssm_color(ssm_bits)
        ssm_text = ssm_label(ssm_bits)
        row = (channel, lru, label, name, value, units, ssm_text)
        if key in self._monitor_rows:
            iid = self._monitor_rows[key]
            self._tree.item(iid, values=row)
            self._tree.tag_configure(str(key), foreground=color)
        else:
            iid = self._tree.insert("", "end", values=row, tags=(str(key),))
            self._tree.tag_configure(str(key), foreground=color)
            self._monitor_rows[key] = iid

    def _update_val_row(self, vid, desc, result, value, reason):
        color = result_color(result)
        icon  = {"PASS": "✓", "FAIL": "✗", "MISSED": "?",
                 "PENDING": "…"}.get(result, "?")
        row = (vid, desc, f"{icon} {result}", value, reason)
        if vid in self._val_rows:
            iid = self._val_rows[vid]
            self._val_tree.item(iid, values=row)
            self._val_tree.tag_configure(vid, foreground=color)
        else:
            iid = self._val_tree.insert("", "end", values=row, tags=(vid,))
            self._val_tree.tag_configure(vid, foreground=color)
            self._val_rows[vid] = iid

    def _poll_ui_queue(self):
        try:
            while True:
                msg = self._ui_queue.get_nowait()
                kind = msg[0]
                if kind == "log":
                    self._log_event(msg[1], msg[2] if len(msg) > 2 else "")
                elif kind == "conn_status":
                    self._set_conn_status(msg[1], msg[2])
                elif kind == "monitor":
                    _, key, ch, lru, lbl, name, val, units, ssm, wc, pe = msg
                    self._update_monitor_row(key, ch, lru, lbl, name,
                                             val, units, ssm)
                    self._words_lbl.config(text=f"{wc:,}")
                    self._parity_lbl.config(
                        text=str(pe), fg=RED if pe > 0 else FG)
                    if ch and lru:
                        self._set_conn_status(
                            f"CONNECTED — {ch}", GREEN)
                elif kind == "val_update":
                    _, vid, desc, result, value, reason = msg
                    self._update_val_row(vid, desc, result, value, reason)
                elif kind == "buttons":
                    self._listen_btn.config(state="normal")
                    self._stop_btn.config(state="disabled")
        except Exception:
            pass
        self.after(100, self._poll_ui_queue)


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = ReceiverApp()
    app.mainloop()
